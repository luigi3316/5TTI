﻿using System;

namespace JeuDame_Projet
{
    class Program
    {
        static void Main(string[] args)
        {
            string player1 = "";
            Console.WriteLine("comment vous appeler vous?", player1);
            player1 = Console.ReadLine();

            int[,] Tab_Pion = new int[10, 10];
            ConstruireMatrice(ref Tab_Pion);
            PionBlanc(ref Tab_Pion);
            PionNoir(ref Tab_Pion);
            AfficherMatrice(Tab_Pion);
        }

        static void ConstruireMatrice(ref int[,] Tab_pion)
        {
            int nbrLigne = Tab_pion.GetLength(0);
            int nbrColonne = Tab_pion.GetLength(1);
            for (int i = 0; i < nbrLigne; i++)
            {
                for (int j = 0; j < nbrColonne; j++)
                {
                    Tab_pion[i, j] = 0;
                }
            }
        }

        static void AfficherMatrice(int[,] Tab_Pion)
        {
            int nbrLigne = Tab_Pion.GetLength(0);
            int nbrColonne = Tab_Pion.GetLength(1);

            for (int i = 0; i < nbrLigne; i++)
            {
                for (int j = 0; j < nbrColonne; j++)
                {
                    Console.Write(Tab_Pion[i, j]);
                }
                Console.WriteLine();
            }

        }
        static void PionBlanc(ref int[,] Tab_Pion) // placement des pions blanc sur le plateau de jeu
        {

            for (int i = 0; i < 4; i++)
            {
                int StartValue;
                if (i % 2 == 0) //modulo= paire ou impaire
                {
                    StartValue = 0;
                }

                else
                {
                    StartValue = 1;
                }

                for (int j = StartValue; j < 10; j = j + 2)
                {
                    Tab_Pion[i, j] = 1;
                }
            }
        }

        static void PionNoir(ref int[,] Tab_Pion) //placement des pions noirs sur le plateau de jeu
        {

            for (int i = 6; i < 10; i++)
            {
                int StartValue;
                if (i % 2 == 0) //modulo= paire ou impaire
                {
                    StartValue = 0;
                }

                else
                {
                    StartValue = 1;
                }

                for (int j = StartValue; j < 10; j = j + 2)
                {
                    Tab_Pion[i, j] = 2;
                }
            }
        }

        static void AvancementPionBlanc(ref int[,] Tab_Pion, ref string player1)
        {
           
            Console.WriteLine("A votre tour de jouer");
            Console.WriteLine("quelle pion voulez vous deplacer", player1);

        }
    }
}
